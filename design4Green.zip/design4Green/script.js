const tableList = document.getElementById('table');
const codePostal = document.getElementById('COM');
const libDep = document.getElementById('Libcom');
const tableHisto = document.getElementById('historique');
let buffer = [];

COM.addEventListener('keyup', (e) => {
    if (event.keyCode==13){
    const searchString = e.target.value.toLowerCase();

    const resultat = buffer.filter((ville) => {
        return (
            ville.COM.toLowerCase().includes(searchString)
        );
    });
    afficherVille(resultat);
}});

Libcom.addEventListener('keyup', (e) => {
    if (event.keyCode==13){
    const searchString = e.target.value.toLowerCase();

    const resultat = buffer.filter((ville) => {
        return (
            ville.Libcom.toLowerCase().includes(searchString)
        );
    });
    afficherVille(resultat);
}});


const chargerVilles = async () => {
    try {
        const res = await fetch("./data.json");
        buffer = await res.json();
        while(buffer.lengh < 10) {
        afficherVille(buffer);
        }
    } catch (err) {
        console.error(err);
    }
};

const titre = `<TR>
				<TH>Nom Commune</TH>
                <TH>Code Iris</TH>
				<TH>Nom Iris</TH>
				<TH>Population</TH>
				<TH>Score Global</TH>
				<TH>Acces aux Interfaces Numérique</TH>
				<TH>Acces à l'information</TH>
				<TH>Compétence Administrative</TH>
				<TH>Compétence Numérique scolaire</TH>
				<TH>Global Acces </TH>
                <TH>Compétence Global</TH>
			</tr>`;

const afficherVille = (villes) => {
    const htmlString = villes.map((ville) =>
    {
        return `
            <tr>
                <td>${ville.Libcom}</td>
                <td>${ville.Code_Iris}</td>
                <td>${ville.Nom_Iris}</td>
                <td>${ville.P16_Pop}</td>
                <td>${ville.SCORE_GLOBAL_region}</td>
                <td>${ville.ACCES_AUX_INTERFACES_NUMERIQUES_region}</td>
                <td>${ville.ACCES_A_LINFORMATION_region}</td>
                <td>${ville.COMPETENCES_ADMINISTATIVES_region}</td>
                <td>${ville.COMPETENCES_NUMERIQUESSCOLAIRES_region}</td>
                <td>${ville.GLOBAL_ACCES_region}</td>
				<td>${ville.GLOBAL_COMPETENCES_region}</td>
			</tr>
        `;
        })
        .join('');
        const htmlString2 = villes.map((ville) => {
            return `
                [${ville.Libcom},
                ${ville.Code_Iris},
                ${ville.SCORE_GLOBAL_region},
                ${ville.Nom_Iris},
                ${ville.P16_Pop},
                ${ville.SCORE_GLOBAL_region},
                ${ville.ACCES_AUX_INTERFACES_NUMERIQUES_region},
                ${ville.ACCES_A_LINFORMATION_region},
                ${ville.COMPETENCES_ADMINISTATIVES_region},
                ${ville.COMPETENCES_NUMERIQUESSCOLAIRES_region},
                ${ville.GLOBAL_ACCES_region},
				${ville.GLOBAL_COMPETENCES_region},
				]<br>
        `;
        })
	
        .join('');
    tableList.innerHTML = titre + htmlString;
	tableHisto.innerHTML += htmlString2;
};

chargerVilles();

